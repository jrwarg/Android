package com.example.appminhaidade

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper


// OBSERVAÇÃO IMPORTANTE:
// Para a tela splash aparecer, é necessário editar o AndroidManifest.xml - conforme feito

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activy_splash)

        Handler(Looper.myLooper()!!).postDelayed({
            val intent = Intent(this,MainActivity::class.java)
            // troca de tela
            startActivity(intent)
            // para não voltar
            finish()
        }, 4000)
    }
}

